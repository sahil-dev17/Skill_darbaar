import React, { useState } from "react";
import axiosInstance from "../utils/axiosInstance";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: "",
    first_name: "",
    last_name: "",
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      setLoading(true);

      const res = await axiosInstance.post("/user/register", form);

      // If backend sends token (optional)
      if (res.data?.token) {
        localStorage.setItem("token", res.data.token);
      }

      navigate("/"); // or dashboard
    } catch (err) {
      setError(
        err.response?.data?.message || "Registration failed"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div
        className="w-full max-w-xl max-h-screen overflow-auto
        rounded-xl p-6 border border-gray-300 shadow-md"
      >
        {/* TITLE */}
        <h2 className="text-2xl font-semibold mb-6 text-center">
          Register
        </h2>

        {/* ERROR */}
        {error && (
          <p className="mb-4 text-sm text-red-600 text-center">
            {error}
          </p>
        )}

        {/* FORM */}
        <form className="space-y-5" onSubmit={handleSubmit}>
          {/* Title + First Name */}
          <div className="flex gap-4">
            <div className="w-1/3">
              <label className="text-sm font-medium">Title</label>
              <select
                name="title"
                value={form.title}
                onChange={handleChange}
                className="w-full mt-1 p-2 rounded-md border outline-none"
                required
              >
                <option value="">Select</option>
                <option value="Mr">Mr</option>
                <option value="Ms">Ms</option>
              </select>
            </div>

            <div className="w-2/3">
              <label className="text-sm font-medium">First Name</label>
              <input
                type="text"
                name="first_name"
                value={form.first_name}
                onChange={handleChange}
                className="w-full mt-1 p-2 rounded-md border outline-none"
                placeholder="Enter first name"
                required
              />
            </div>
          </div>

          {/* Last Name */}
          <div>
            <label className="text-sm font-medium">Last Name</label>
            <input
              type="text"
              name="last_name"
              value={form.last_name}
              onChange={handleChange}
              className="w-full mt-1 p-2 rounded-md border outline-none"
              placeholder="Enter last name"
              required
            />
          </div>

          {/* Email */}
          <div>
            <label className="text-sm font-medium">Email</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="w-full mt-1 p-2 rounded-md border outline-none"
              placeholder="Enter email"
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="text-sm font-medium">Password</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              className="w-full mt-1 p-2 rounded-md border outline-none"
              placeholder="Enter password"
              required
            />
          </div>

          {/* LOGIN LINK */}
          <p
            className="text-center text-sm text-gray-600 cursor-pointer"
            onClick={() => navigate("/login")}
          >
            Already have an account?{" "}
            <span className="underline text-blue-600">
              Login now
            </span>
          </p>

          {/* BUTTON */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg text-white font-semibold
            bg-[#50c2b4] hover:bg-[#3fa89c] transition disabled:opacity-60"
          >
            {loading ? "Registering..." : "Register"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Register;
