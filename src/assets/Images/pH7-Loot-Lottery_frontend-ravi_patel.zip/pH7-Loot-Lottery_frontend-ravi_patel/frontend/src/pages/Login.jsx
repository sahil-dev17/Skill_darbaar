import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../utils/axiosInstance";

const Login = () => {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      setLoading(true);

      const res = await axiosInstance.post("/user/login", form);

      // Save token if provided
      if (res.data?.token) {
        localStorage.setItem("token", res.data.token);
      }

      // Optional: store user info
      if (res.data?.user) {
        localStorage.setItem("user", JSON.stringify(res.data.user));
      }

      navigate("/"); // or dashboard
    } catch (err) {
      setError(
        err.response?.data?.message || "Invalid email or password"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div
        className="w-full max-w-xl max-h-screen overflow-auto
        rounded-xl p-6 border border-gray-300 shadow-md"
      >
        {/* TITLE */}
        <h2 className="text-2xl font-semibold mb-6 text-center">
          Login
        </h2>

        {/* ERROR */}
        {error && (
          <p className="mb-4 text-sm text-red-600 text-center">
            {error}
          </p>
        )}

        {/* FORM */}
        <form className="space-y-5" onSubmit={handleSubmit}>
          {/* Email */}
          <div>
            <label className="text-sm font-medium">Email</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              className="w-full mt-1 p-2 rounded-md border outline-none"
              placeholder="Enter email"
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="text-sm font-medium">Password</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              className="w-full mt-1 p-2 rounded-md border outline-none"
              placeholder="Enter password"
              required
            />
          </div>

          {/* REGISTER LINK */}
          <p
            className="text-center text-sm text-gray-600 cursor-pointer"
            onClick={() => navigate("/register")}
          >
            Don&apos;t have an account?{" "}
            <span className="underline text-blue-600">
              Register now
            </span>
          </p>

          {/* BUTTON */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg text-white font-semibold
            bg-[#50c2b4] hover:bg-[#3fa89c] transition disabled:opacity-60"
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
