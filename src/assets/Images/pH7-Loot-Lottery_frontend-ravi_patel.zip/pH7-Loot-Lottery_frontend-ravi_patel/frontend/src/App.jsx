import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";

import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminRoute from "./routes/AdminRoute";
import Navbar from "./components/Navbar";
import Register from "./pages/Register";
import Login from "./pages/Login";
import LotteryCards from "./components/LotteryCards";

// Layout to control Navbar visibility
const Layout = () => {
  const location = useLocation();

  // ❌ Hide Navbar on admin pages
  const hideNavbar =
    location.pathname.startsWith("/admin") ||
    location.pathname.startsWith("/dashboard");

  return (
    <>
      {!hideNavbar && <Navbar />}
      {!hideNavbar && <LotteryCards />}

      <Routes>
        {/* PUBLIC ROUTES */}
        <Route path="/register" element={<Register />} />
         <Route path="/login" element={<Login />} />

        {/* ADMIN ROUTES */}
        <Route path="/admin/login" element={<AdminLogin />} />

        <Route
          path="/dashboard"
          element={
            <AdminRoute>
              <AdminDashboard />
            </AdminRoute>
          }
        />
      </Routes>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Layout />
    </BrowserRouter>
  );
};

export default App;
