import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FiMenu, FiX, FiUser, FiLogOut } from "react-icons/fi";

const Navbar = () => {
  const navigate = useNavigate();

  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const logout = () => {
    // localStorage.clear(); // if needed
    setProfileOpen(false);
    navigate("/login");
  };

  return (
    <nav className="w-full bg-white shadow-md relative">
      {/* MAIN BAR */}
      <div className="h-[70px] flex items-center justify-between px-4 md:px-10">
        
        {/* LOGO */}
        <div
          className="text-2xl font-extrabold cursor-pointer"
          onClick={() => navigate("/")}
        >
          pH7<span className="text-teal-400">Loot</span>
        </div>

        {/* RIGHT SIDE (DESKTOP) */}
        <div className="hidden md:flex items-center gap-6 relative">
          <button
            onClick={() => navigate("/register")}
            className="px-6 py-2 rounded-full text-sm font-semibold text-white
            bg-gradient-to-b from-orange-300 to-orange-600"
          >
            REGISTER
          </button>

          <button
            onClick={() => navigate("/login")}
            className="px-6 py-2 rounded-full text-sm font-semibold
            text-teal-400 border-2 border-teal-400 hover:bg-teal-400 hover:text-white transition"
          >
            LOG IN
          </button>

          {/* AVATAR */}
          <div className="relative">
            <div
              onClick={() => setProfileOpen(!profileOpen)}
              className="w-10 h-10 rounded-full bg-teal-400 flex items-center justify-center
              text-white cursor-pointer"
            >
              <FiUser />
            </div>

            {/* PROFILE POPUP */}
            {profileOpen && (
              <div className="absolute right-0 top-12 w-40 bg-white border rounded-lg shadow-lg overflow-hidden">
                <button
                  onClick={() => {
                    navigate("/profile");
                    setProfileOpen(false);
                  }}
                  className="w-full px-4 py-3 text-left text-sm hover:bg-gray-100"
                >
                  Profile
                </button>

                <button
                  onClick={logout}
                  className="w-full px-4 py-3 text-left text-sm text-red-600 hover:bg-gray-100 flex items-center gap-2"
                >
                  <FiLogOut /> Logout
                </button>
              </div>
            )}
          </div>
        </div>

        {/* MOBILE MENU ICON */}
        <div className="md:hidden text-2xl cursor-pointer">
          {menuOpen ? (
            <FiX onClick={() => setMenuOpen(false)} />
          ) : (
            <FiMenu onClick={() => setMenuOpen(true)} />
          )}
        </div>
      </div>

      {/* MOBILE MENU */}
      {menuOpen && (
        <div className="md:hidden flex flex-col gap-4 px-4 pb-6 border-t">
          <button
            onClick={() => {
              navigate("/register");
              setMenuOpen(false);
            }}
            className="w-full py-3 rounded-lg text-white font-semibold
            bg-gradient-to-b from-orange-300 to-orange-600"
          >
            REGISTER
          </button>

          <button
            onClick={() => {
              navigate("/login");
              setMenuOpen(false);
            }}
            className="w-full py-3 rounded-lg font-semibold
            text-teal-400 border-2 border-teal-400"
          >
            LOG IN
          </button>

          {/* MOBILE PROFILE */}
          <button
            onClick={() => {
              navigate("/profile");
              setMenuOpen(false);
            }}
            className="w-full py-3 rounded-lg border text-left flex items-center gap-2"
          >
            <FiUser /> Profile
          </button>

          <button
            onClick={logout}
            className="w-full py-3 rounded-lg border text-left text-red-600 flex items-center gap-2"
          >
            <FiLogOut /> Logout
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
