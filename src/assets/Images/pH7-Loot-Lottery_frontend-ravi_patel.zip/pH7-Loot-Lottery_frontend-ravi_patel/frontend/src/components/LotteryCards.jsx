import React from "react";
import { FiChevronLeft, FiChevronRight, FiClock } from "react-icons/fi";

const data = [
  {
    title: "MEGAMILLIONS",
    amount: "₹24,200,000,000",
    time: "2d : 12h : 27m : 21s",
    price: "₹725.00",
  },
  {
    title: "CASH4LIFE",
    amount: "₹74,500 a day for life",
    time: "0d : 10h : 27m : 21s",
    price: "₹252.00",
  },
  {
    title: "POWERBALL",
    amount: "₹19,000,000,000",
    time: "0d : 12h : 26m : 21s",
    price: "₹375.00",
  },
];

const LotteryCards = () => {
  return (
    <div className="w-full bg-gray-100 py-6 relative">
      <div className="max-w-6xl mx-auto px-6 flex items-center gap-4">
        
        {/* LEFT ARROW */}
        <button className="hidden md:flex w-10 h-10 rounded-full bg-white shadow items-center justify-center">
          <FiChevronLeft />
        </button>

        {/* CARDS */}
        <div className="flex gap-6 overflow-x-auto scrollbar-hide">
          {data.map((item, index) => (
            <div
              key={index}
              className="min-w-[320px] bg-white rounded-xl shadow-md p-4 border"
            >
              {/* TITLE */}
              <h3 className="font-bold text-lg mb-2">
                {item.title}
              </h3>

              {/* AMOUNT */}
              <p className="text-xl font-extrabold mb-3">
                {item.amount}
              </p>

              {/* TIMER */}
              <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                <FiClock />
                <span>{item.time}</span>
              </div>

              {/* PRICE */}
              <p className="text-sm text-gray-600 mb-4">
                {item.price}
              </p>

              {/* ACTIONS */}
              <div className="flex items-center justify-between">
                <button className="text-sm text-teal-500 flex items-center gap-1">
                  ℹ️ About
                </button>

                <button className="px-5 py-1.5 rounded-full border-2 border-orange-400
                text-orange-500 font-semibold hover:bg-orange-400 hover:text-white transition">
                  Play now
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* RIGHT ARROW */}
        <button className="hidden md:flex w-10 h-10 rounded-full bg-white shadow items-center justify-center">
          <FiChevronRight />
        </button>
      </div>
    </div>
  );
};

export default LotteryCards;
